const router = require('express').Router();
const { isUser, isGuest } = require('../middleware/gurads.js');
const { createAuction, placeBid, getAuctionById, updateAuction } = require('../services/post.js');
const { auctionViewModel } = require('../util/mappers.js');



const { mapErrors } = require('../util/mappers.js');

router.get('/create', isUser(), async (req, res) => {
    res.render('create', { title: 'Create Page' });
});

router.post('/create', isUser(), async (req, res) => {
    const userId = req.session.user._id;

    const auction = {
        title: req.body.title,
        description: req.body.description,
        category: req.body.category,
        imageUrl: req.body.imageUrl,
        price: req.body.price,
        author: userId
    };

    console.log(auction);
    try {
        await createAuction(auction);
        res.redirect('/browse');
    } catch (err) {
        const errors = mapErrors(err);
        res.render('create', { title: 'Create Post', data: auction, errors })
    }
});

router.post('/bid/:id', isUser(), async (req, res) => {
    const id = req.params.id;

    try {
        const auction = auctionViewModel(await getAuctionById(id));
        await placeBid(id, req.session.user._id);
        auction.hasBided = true;

        res.redirect('/details/' + id);
    } catch (err) {
        const errors = mapErrors(err);
        res.render('home', { title: 'Browse Page', errors })
    }
});


router.get('/edit/:id', isUser(), async (req, res) => {
    const id = req.params.id;

    if (req.session.user._id != post.author.id) {
        return res.redirect('/login');
    }

    res.render('edit', { title: `Edit Post` });
});

router.post('/edit/:id', async (req, res) => {
    const id = req.params.id;

    const existing = auctionViewModel((await getAuctionById(id)));

    if (req.session.user._id != existing.author.id) {
        return res.redirect('/login');
    }

    const auction = {
        title: req.body.title,
        keyword: req.body.keyword,
        location: req.body.location,
        date: req.body.date,
        image: req.body.image,
        description: req.body.description,
    };

    try {
        await updatePost(id, auction);
        res.redirect('/catalog/' + id);
    } catch (err) {
        const errors = mapErrors(err)
        post.id = id;
        res.render('edit', { title: 'Edit Post', post, errors });
    }
});
module.exports = router;