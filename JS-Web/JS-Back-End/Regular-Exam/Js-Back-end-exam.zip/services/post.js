const Auction = require('../models/Auction.js');

async function createAuction(auction) {
    const result = new Auction(auction);
    await result.save();

    return result;
}

async function getAuctions() {
    return Auction.find({});
}

async function getAuctionById(id) {
    return Auction.findById(id).populate('author', 'email firstName lastName').populate('bidder', 'email firstName lastName');
}

async function placeBid(id, userId) {
    const existing = await getAuctionById(id);
    existing.bidder = userId;
    await existing.save();
}


async function updateAuction(id, auction) {
    const existing = await Post.findById(id);

    existing.title = auction.title;
    existing.category = auction.category;
    existing.imageUrl = auction.imageUrl;
    existing.price = auction.price;
    existing.description = auction.description;

    await existing.save();

}
module.exports = {
    createAuction,
    getAuctions,
    getAuctionById,
    placeBid,
    updateAuction
}